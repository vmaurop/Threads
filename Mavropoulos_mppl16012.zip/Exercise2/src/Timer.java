


import java.util.Scanner;



public class Timer {

    
    
    public static void main(String[] args)
    {
        
        /*1 Ερώτημα χρόνος εκτέλεσης προγράμματος  
        
        Παρατηρήσεις
        Κατά την εκτέλεση του προγράμματος ο χρόνος διαφέρει κάθε 
        φορά για λίγα ms..Το οποίο δεν μπορούμε να το αντιληφθούμε
        Ο λόγος ειναι οτι εκτελούνται και άλλες διεργασίες
        
        Συγρκίνοτας με το αποτέλεσμα των σημειώσεων(το ίδιο πρόγραμμα)
        Αν θεωρήσουμε μια μέση τιμή του χρόνου εκτέλεσης  περίπου 1.65 sec
        βλέπουμε οτι σε σχέση με το παράδειγμα τών σημειώσεων 1.18 sec
        (χρησιμοποιώντας long και οχι Long)
        Επίσης το ίδιο πρόγραμμα στον υπολογιστή ενος συμφοιτητή μου είναι
        περίπου 1.25 sec
        Άρα ο υπολογιστής μου ειναι πιο αργός 
        */ 
        
        long count1=0;
        long starttime = System.nanoTime();   
        long sum = 0L;   
        for(long i=0;i<=Integer.MAX_VALUE;i++)
        {
             count1++;
            sum = sum +i;
           
            
        }
        System.out.println("The sum is:"+sum);
        long endtime = System.nanoTime();
        
        
        long duration = endtime - starttime;
        System.out.println("time/ns:"+duration);
        
       double duration_sec = (double)duration/1000000000.0;
       System.out.println("time/sec:"+duration_sec);
       
       System.out.println("the calculation per nanosecond:"+Math.round(duration*1000000d/count1)/1000000d);
        
        
      
      
        
        System.out.println("-----------second program--------------------");    
      
      
      
      /*2 Ερώτημα υπολογισμός πλήθος πράξεων σε συγκεκριμένο χρονικό διάστημα
      Παρατηρήσεις
      Στο συγκεκριμένο πρόγραμμα δίνουμε εμείς το χρόνο που θέλουμε να εκτελεί
      τις πράξεις και μας βγάζει το άθροισμα και το πλήθος των πράξεων
      Ωστόσο αν δώσουμε τον ίδιο χρόνο με το χρόνο εκτέλεσης του προηγούμενου
      βλέπουμε οτι το άθροισμα ειναι μικρότερο διοτί εκτελεί  επιπλέον
      πράξη-συνθήκη if(System.nanoTime()-starttime1>=t) ελέγχει δηλαδή αν χρόνος
      εκτέλεσης ειναι πάνω απο το χρόνο που εισάγαμε ώστε να σταματήσει να υπολογίζει
      Προφανώς θέλει περισσότερο χρόνο.
      Επίσης αν εισάγουμε χρόνο πέρα απο τα όρια ή χαρακτήρες τερματίζει(try-catch)
        
      */
        long sum1=0L;
        long t = 0;
        int count =0;
        System.out.print("please give me time in nanosececonds:");
        
     try
    {    
        Scanner in = new Scanner(System.in);
        t= in.nextLong();
        
       
           
        long starttime1 = System.nanoTime();   
        for(long j=0;j<=Integer.MAX_VALUE;j++)
        {
            
           
            if(System.nanoTime()-starttime1>=t)
            {
                break;
            }
            sum1 = sum1 +j;
            count++;
            
        }
     }
    catch(Exception e)
        {
            System.out.println("wrong input");
            System.exit(0);
        }
    
    
        System.out.println("The sum is:"+sum1);
       
        
        System.out.println("The number of numerical operations is:"+count);
        
    }
}    
        
       
        
        
        
       
        
   
   
   
        
    
  
