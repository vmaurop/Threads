
public class Threads {

   
    public static void main(String[] args) 
    {
       /*      Δημιουργία των Thread με ανώνυμη κλάση(Through an anonymous class) που τυπώνει συγκεριμένο γράμμα(επιπλέον το όνομα του Thread και το πόσες φορές)
        Τα threads τρέχουν παράλληλα και στίς δυο περίπτωσεις!(3 Thread για κάθε περίπτωση)
        
        
        Παρατηρήσεις:
        Στην πρώτη περίπτωση  δεν υπάρχει χρονοκαθυστέρηση συνεπώς βλέπουμε ελάχιστες εναλλαγές 
        Στη δεύτερη περίπτωση λόγω της χρονοκαθυστέρησης(0.5sec) υπάρχουνε πολλές εναλλαγές και σε κάμια περίπτωση δεν συγχρονίζονται και η έξοδος δεν είναι δεσμευτική
        και προφανώς η διαφορά είναι εμφανής
        
        Επίσης κατα την μεταγλώττιση του προγράμματος έχουμε 6+1 class file διότι ένα νήμα είναι μια ανεξάρτητη πορεία εκτέλεσης μέσα στο κώδικα του προγράμματος
        Άρα έχουμε 6 class file(3+3 νήματα με βάση την άσκηση να εκτελούνται παράλληλα) και 1 class file που αφορά τη διεργασία του προγράμματος

        
        
        
        

        
*/
        
        
        
        
            
            Thread a = new Thread()   
            {
                public void run()
                 {
                     for(int i=0;i<100;i++)
                     {
                         
                         System.out.println(Thread.currentThread().getName()+":     A"+"    times:"+i);

                     }
                 }
            };
            
            
            
            Thread b = new Thread()   
          {
            public void run()
            {
                for(int i=0;i<100;i++)
                {
                    System.out.println(Thread.currentThread().getName()+":      B"+"    times:"+i);
                }
            }
         };
         
         
         
         
         
          Thread c = new Thread()   
        {
            public void run()
            {
                for(int i=0;i<100;i++)
                {
                    
                    System.out.println(Thread.currentThread().getName()+":      C"+"    times:"+i);
                }
            }
        };
       
       
       a.start();
       b.start();
       c.start();
       
       
       
       
       
       Thread a1 = new Thread()   
        {
            public void run()
            {
                for(int i=0;i<20;i++)
                {
                    try
                    {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e)
                    {

                    }

                    System.out.println(Thread.currentThread().getName()+":      A"+"    times:"+i);
                }
            }
        };
        
        
        
        
        Thread b1 = new Thread()   
        {
            public void run()
            {
                for(int i=0;i<20;i++)
                {
                    try
                    {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e)
                    {

                    }

                    System.out.println(Thread.currentThread().getName()+":      B"+"    times:"+i);
                }
            }
        };
        
        
        
        Thread c1 = new Thread()   
        {
            public void run()
            {
                for(int i=0;i<20;i++)
                {
                    try
                    {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e)
                    {

                    }

                    System.out.println(Thread.currentThread().getName()+":      C"+"    times:"+i);
                }
            }
        };
        
        
        
       
       
       
       a1.start();
       b1.start();
       c1.start();
       
    }

    
    
}
