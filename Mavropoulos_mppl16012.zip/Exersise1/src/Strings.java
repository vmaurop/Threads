
 
public class Strings {

    
    public static void main(String[] args) 
    {
         String x = "we are the students of the Department of Informatics.All students should know how to programm in Java and C";
       
        //Ερώτημα 1.Από το παραπάνω κείμενο μας τυπώνει απο τη λέξη "Department" έως "should know"
        
        int index1 = x.indexOf("Department");           //ακέραια μεταβλητή που μας δείχνει τη θέση της λέξης "Department"
        int index2 = x.indexOf("should know");          //ομοίως για τη λέξη "should know"
        String y = "should know";  
        
        String z=x.substring(index1, index2+y.length());     //το κείμενο που θέλουμε ειναι απο τη θέση index1 εως την index2 +  το μήκος της λέξης "should know" y.length()
        System.out.println(z);
         
         
         
       
       
       //Ερώτημα 2.Μετράει κ τυπώνει πόσες φορές εμαφανίζεται η λέξη "students"
       
        String s = "students";
        int count = 0;             
         while(x.contains("students"))    //Όσο περιέχεται η λέξη    "students"  
         {
             count++;                                        //αύξησε το μετρητή
             x=x.substring(x.indexOf("students")+s.length());   // ξεκίνα απο τη θέση(ακέραιος) που υπάρχει η λέξη "students" + το μήκος της λέξης
         }
        
       System.out.println("The word \"students\" appears:"+count+" times");   
    }
    
}
